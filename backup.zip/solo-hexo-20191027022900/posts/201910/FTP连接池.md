title: FTP连接池
date: '2019-10-10 20:17:06'
updated: '2019-10-10 20:17:06'
tags: [连接池, FTP]
permalink: /articles/2019/10/10/1570709826701.html
---


> 背景：公司需要用FTP来进行文件上传，上传需要频繁的建立和销毁连接，很耗费性能，所以就考虑到使用连接池来复用连接，减少建立和销毁连接造成的消耗。

## 一、实现原理和细节

连接池的实现使用了*commons-pool2*的jar包，该jar下包含了对池、对象工厂以及池对象的基本定义。并提供了常用的实现。下面分别来说池、对象工厂和池对象。

### 1、池对象

连接池中使用的所有对象都是由`PoolObject`接口封装后的对象。`PoolObject`接口提供了获取当前对象的状态(比如说空闲，正在使用)、获取空闲时间，上次被借用的时间等多个方法。*commons-pool2*提供了一个默认的接口实现类`DefaultPooledObject`和基于`DefaultPooledObject`的软引用实现类`PooledSoftReference`。后者将对象变为软引用，使GC可以在内存不足的时候回收这些对象。

### 2、池对象工厂

*commons-pool2*推荐的对池对象操作方法是通过工厂来进行。*commons-pool2*提供了工厂的接口`PooledObjectFactory`，该工厂提供了对池对象的创建、销毁、验证是否可用、以及激活和钝化对象的方法。

其中激活和钝化对象的方法分别在从池中获取和返还对象时候会调用。因为池在借还对象的时候都会调用工厂的方法，所以要实现池必须要实现一个工厂，而*commons-pool2*提供的基本实现类`BasePooledObjectFactory`里面大多是空实现，所以为了自己需要的逻辑，应该实现`PooledObjectFactory`接口并重写方法。

### 3、对象池

![对象池.jpg](https://i.loli.net/2019/10/10/Et2cYZ3kSyJepbG.jpg)



对象池有两个基础的接口 `ObjectPool` 和 `KeyedObjectPool`, 持有的对象都是由 `PooledObject` 封装的池化对象。 `KeyedObjectPool` 的区别在于其是用键值对的方式维护对象。

`ObjectPool` 和 `KeyedObjectPool` 分别有一个默认的实现类`GenericObjectPool` 和 `GenericKeyedObjectPool` 可以直接使用，他们的公共部分和配置被抽取到了 `BaseGenericObjectPool` 中。

`ObjectPool`只包含基本的对象借还方法，而对象池的常用设置则别封装在`BaseGenericObjectPool`中。`GenericObjectPool`和`GenericKeyedObjectPool`分别有一个`config`类来配置对象池的参数。这里具体不在列举配置。

## 二、FTP连接池实现

```java
@Component
public class FtpClientPooledObjectFactory implements PooledObjectFactory<FTPClient>{
	
	
	@Autowired
	private FtpConfig config;
	
	@Override
	public PooledObject<FTPClient> makeObject() throws Exception {
		FTPClient client = new FTPClient();
		client.connect(config.getIp(), config.getPort());
		if(FTPReply.isPositiveCompletion(client.getReplyCode())){
			boolean login = client.login(config.getUserName(), config.getPassword());
			if(!login) {
				throw new IllegalArgumentException("用户名或者密码错误！！");
			}
		}else {
			throw new RuntimeException("连接FTP服务器失败！");
		}
		if (config.getDataConMode().equals("PASV")) {
			// 设置数据链接方式为被动模式
			client.enterLocalPassiveMode();
		} else if (config.getDataConMode().equals("PORT")) {
			// 设置数据链接方式为主动模式
			client.enterLocalActiveMode();
		}
		return new DefaultPooledObject<FTPClient>(client);
	}

	@Override
	public void destroyObject(PooledObject<FTPClient> p) throws Exception {
		FTPClient client = p.getObject();
		if(client.isConnected()) {
			client.logout();
			client.disconnect();
		}
	}

	@Override
	public boolean validateObject(PooledObject<FTPClient> p) {
		FTPClient client = p.getObject();
		return client.isAvailable();
	}

	@Override
	public void activateObject(PooledObject<FTPClient> p) throws Exception {
		//可以理解为借连接时的前处理
		System.out.println("我取出了一个链接"+p.getObject().isConnected());
	}

	@Override
	public void passivateObject(PooledObject<FTPClient> p) throws Exception {
		p.getObject().changeWorkingDirectory("/");
        //使用后的ftp连接会保持在切换的目录，所以需要把目录切换回根目录
        //可以理解为后处理
		
	}

```



创建连接池代码

```java
private GenericObjectPool<FTPClient> getPool() {
    GenericObjectPoolConfig<FTPClient> config = new GenericObjectPoolConfig<FTPClient>();
    config.setMaxIdle(Optional.ofNullable(ftpConfig.getMaxIdle()).orElseGet(()->4));
    config.setMaxTotal(Optional.ofNullable(ftpConfig.getMaxIdle()).orElseGet(()->GenericObjectPoolConfig.DEFAULT_MAX_TOTAL));
    config.setMinIdle(Optional.ofNullable(ftpConfig.getMinIdle()).orElseGet(()->0));
    pool = new  GenericObjectPool<FTPClient>(factory,config);
    pool.setLifo(false);
    return pool;
}
```


