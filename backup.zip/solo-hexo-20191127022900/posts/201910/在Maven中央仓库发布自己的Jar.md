title: 在Maven中央仓库发布自己的Jar
date: '2019-10-10 20:18:46'
updated: '2019-10-14 21:11:10'
tags: [Maven]
permalink: /articles/2019/10/10/1570709926517.html
---

> 前言写了项目想要发布到中央仓库方便以后再使用直接导入依赖，就去研究了下怎么deploy，结果一步一个坎。折腾了几个小时终于成功发布。算是历经磨难。所以这篇博客就把上传的步骤以及注意点记录下来，方便查看。

## 一、创建账号并提交工单

想要把自己的项目jar包上传到maven中央仓库，首先必须要有一个账号。

[https://issues.sonatype.org](https://issues.sonatype.org/)

在这个地址注册一个账号，这个账号也是你后来查看项目上传情况的账号。

注册好之后创建工单，创建工单的意义是要申请`groupId`，如果你以前已经申请过，并且还是要在这个`groupId`下面，那么新写的项目就可以不需要在新建工单。

![1.jpg](https://i.loli.net/2019/10/06/KqPOStw1Uz92id5.png)

**其中需要注意的地方：**

①`Group Id` ，唯一标识，我用的是`com.github.xxxxx`  如果用的是其他的比如：`com.sojson.core` 之类的，管理员会问你这个是不是属于你的网站，告诉他就可以了（用`com.github.xxxxx` 这种比较方便）。官方文档：http://central.sonatype.org/pages/choosing-your-coordinates.html

② `ProjectURL` ，填项目源码的地址，官方有一篇文章说，如果不想公布源码，那么填写一个只含`README` 的项目的地址就可以了。

创建之后在`项目->Community Support Open Source Project Repository Hosting->切换筛选器->我的报告`找到自己的工单

![2.JPG](https://i.loli.net/2019/10/06/UQVq6FnCGBcvTfb.jpg)

如果`groupId`通过了，则会给你发送这样的信息：

> `com.github.mihone` has been prepared, now user(s) `mihone` can:
>
> - Deploy snapshot artifacts into repository https://oss.sonatype.org/content/repositories/snapshots
> - Deploy release artifacts into the staging repository https://oss.sonatype.org/service/local/staging/deploy/maven2
> - Release staged artifacts into repository 'Releases'
>
> please comment on this ticket when you promoted your first release, thanks

表明申请成功，我们可以准备上传了。

## 二、准备`gpg`加密的密钥

### 1、下载并安装

首先在这个网站下载gpg：https://www.gpg4win.org/，安装就一直下一步即可。

之后打开命令窗口 输入 `gpg -version` 验证是否安装成功。

### 2、创建秘钥

```
gpg -gen-key
```

系统会提示你输入用户名和邮箱。

都输入完之后，系统会提示你输入一个`passphrase`作为你的秘钥

**注意：这个秘钥需要一定的复杂度，不然不会通过。**

最后生成的结果大致如下

```
gpg: C:/Users/xxx/AppData/Roaming/gnupg/trustdb.gpg: trustdb created
gpg: key E0EB17B79D4E749D marked as ultimately trusted
gpg: directory 'C:/Users/xxx/AppData/Roaming/gnupg/openpgp-revocs.d' created
gpg: revocation certificate stored as 'C:/Users/xxx/AppData/Roaming/gnupg/openpgp-revocs.d\9E63BF3BC87B6EAD8DF76F0EE0EB17B79D4E749D.rev'
public and secret key created and signed.
```

其中公钥就是`key`： `E0EB17B79D4E749D`

### 3、发布公钥

```
gpg --keyserver hkp://pool.sks-keyservers.net --send-keys E0EB17B79D4E749D
```

至此`gpg`密钥对已经准备就绪。

三、配置maven的settings.xml文件

找到`Maven`安装目录下`conf/settings.xml`文件

```xml
<servers>
    <server>
        <id>ossrh</id><!--唯一id，下面在pom文件里的配置id必须和这个一致-->
        <username>xxx</username><!--上面你在申请groupId时候用的账号名-->
        <password>xxxxxxxxx</password><!--上面你在申请groupId时候用的账号的密码-->
    </server>
</servers>

<profiles>
	 <profile>
      <id>ossrh</id><!--唯一id，同上-->
      <activation>
        <activeByDefault>true</activeByDefault>
      </activation>
      <properties>
        <gpg.executable>F:\GPG\GnuPG\bin\gpg.exe</gpg.executable><!--gpg.exe运行路径-->
        <gpg.passphrase>xxxxxxxxxxx</gpg.passphrase><!-- 上面生成gpg密钥对的时候你设置的私钥-->
      </properties>
    </profile>   
</profiles>
```

## 四、pom文件配置

### 1、项目基本信息

```xml
<name>Redis-MQ</name>
<url>https://github.com/mihone/Redis-MQ</url>
<groupId>com.github.mihone</groupId>
<artifactId>redis-mq</artifactId>
<version>0.1</version>
<description> A light implementation of MQ with Redis</description>
<organization>
    <name>mihone</name>
    <url>https://github.com/mihone</url>
</organization>
<scm>
    <url> https://github.com/mihone/Redis-MQ</url>
    <connection>https://github.com/mihone/Redis-MQ.git</connection>
    <developerConnection>https://github.com/mihone/Redis-MQ</developerConnection>
</scm>
<developers>
    <developer>
        <name>mihone</name>
        <url>https://github.com/mihone</url>
    </developer>
</developers>
<!--如果要上传到maven中央仓库，上面这些必须一个不落的写全。另外对同一项目，每次上传的版本必须不同-->
<licenses>
    <license>
        <name>The Apache Software License, Version 2.0</name>
        <url>http://www.apache.org/licenses/LICENSE-2.0.txt</url>
        <distribution>repo</distribution>
    </license>
</licenses>
<!--licenses固定添加上面这些-->
```

### 2、添加plugins

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-deploy-plugin</artifactId>
    <version>2.8.2</version>
</plugin>
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-gpg-plugin</artifactId>
    <version>1.5</version>
    <executions>
        <execution>
            <id>sign-artifacts</id>
            <phase>verify</phase>
            <goals>
                <goal>sign</goal>
            </goals>
        </execution>
    </executions>
</plugin>
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-source-plugin</artifactId>
    <version>2.2.1</version>
    <executions>
        <execution>
            <id>attach-sources</id>
            <goals>
                <goal>jar-no-fork</goal>
            </goals>
        </execution>
    </executions>
</plugin>
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-javadoc-plugin</artifactId>
    <version>2.9.1</version>
    <executions>
        <execution>
            <id>attach-javadocs</id>
            <goals>
                <goal>jar</goal>
            </goals>
        </execution>
    </executions>
</plugin>
<plugin>
    <groupId>org.sonatype.plugins</groupId>
    <artifactId>nexus-staging-maven-plugin</artifactId>
    <version>1.6.8</version>
    <extensions>true</extensions>
    <configuration>
        <serverId>ossrh</serverId>
        <nexusUrl>https://oss.sonatype.org/</nexusUrl>
        <autoReleaseAfterClose>true</autoReleaseAfterClose>
    </configuration>
</plugin>
```

### 3、上传的仓库配置

```xml
<!--这里的id就是前文说到的唯一id-->
<distributionManagement>
    <snapshotRepository>
        <id>ossrh</id>
        <url>https://oss.sonatype.org/content/repositories/snapshots</url>
    </snapshotRepository>
    <repository>
        <id>ossrh</id>
        <url>https://oss.sonatype.org/service/local/staging/deploy/maven2/</url>
    </repository>
</distributionManagement>
```

## 五、准备就绪，开始上传。

Idea下直接clean之后deploy即可。上传成功后，可以在https://oss.sonatype.org/#stagingRepositories 
看到自己上传的jar包。

因为上面的maven插件包含了自动close和release，如果一切都没有问题，会直接帮你release。如果有问题，则会在这个地方看到哪一步验证失败。解决后重新上传即可。

**tips**

①上传过程中出现找不到，无法执行`gpg`程序

`settings.xml`中配置`<gpg.executable>`直接配置`gpg.exe`的绝对路径

②上传过程中找不到某个类

请检查`Maven`仓库是不是这个包没有下载成功。删除重新下载

Release成功之后会在之前的工单下看到下面这个自动评论，表明上传成功，等待最多两个小时，就能在`search.maven.org`搜到自己上传的包。

> Central sync is activated for `com.github.mihone`. After you successfully release, your component will be published to Central, typically within 10 minutes, though updates to search.maven.org can take up to two hours.

## 六、参考链接

[GPG签名](https://central.sonatype.org/pages/working-with-pgp-signatures.html)

[Maven构建](https://central.sonatype.org/pages/apache-maven.html)
