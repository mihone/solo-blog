title: LogBack学习
date: '2019-10-23 16:58:15'
updated: '2019-10-23 16:58:15'
tags: [LogBack]
permalink: /articles/2019/10/23/1571821095257.html
---

## 1.简介

Logback是springboot默认使用的日志框架

Logback主要由三部分组成

- logback-core
- logback-classic
- logback-access

`logback-core` 是其它模块的基础设施，其它模块基于它构建，显然，`logback-core` 提供了一些关键的通用机制。

logback-classic` 的地位和作用等同于 `Log4J`，它也被认为是 `Log4J` 的一个改进版，并且它实现了简单日志门面 `SLF4J`。`

 `而 `logback-access` 主要作为一个与 `Servlet` 容器交互的模块，比如说`tomcat`或者 `jetty`，提供一些与 `HTTP` 访问相关的功能。

## 2.优势

Logback和log4j都是一个人写的，但是Logback逐渐成为主流的原因主要由以下两点：

- ##### 更快的执行速度

基于先前在log4j上的工作，logback 重写了内部的实现，在某些特定的场景上面，甚至可以比之前的速度快上10倍。在保证logback的组件更加快速的同时，同时所需的内存更加少。

- ##### 充分的测试(健壮性提高)

Logback 历经了几年，数不清小时数的测试。尽管log4j也是测试过的，但是Logback的测试更加充分，跟log4j不在同一个级别。这正是人们选择Logback而不是log4j的最重要的原因。人们都希望即使在恶劣的条件下，你的日记框架依然稳定而可靠。

## 3.配置文件解析

项目启动时Logback会按照以下三个步骤加载配置

> 1. 首先尝试在 classpath下查找文件logback-test.xml；
> 2. 如果文件不存在，则查找文件logback.xml；
> 3. 如果两个文件都不存在，logback用BasicConfigurator自动对自己进行配置，这会导致记录输出到控制台。

本节要解析的是xml文件的配置。

```xml
<!--配置文件最外层标签，标识logback文件-->
<configuration scan="true" scanPeriod="60 seconds" debug="false"></configuration>
<!-- scan=true 当配置文件发生变化时，会自动重新加载配置  -->
<!-- scanPeriod 扫描配置文件的间隔  -->
<!-- debug:当此属性设置为true时，将打印出logback内部日志信息，实时查看logback运行状态。默认值为false  -->
```

```xml
<contextName>demoContext</contextName>
<!-- 每个logger都关联到logger上下文，默认上下文名称为“default”。 
	此配置可以用于区分不同应用程序的日志。 
	一旦设置，不能修改,可以通过%contextName来打印日志上下文名称。 -->
```

```xml
<property name="log.path" value="../log" />
<property resource=".properties"></property>
<!-- 用来定义变量值的标签 -->
<!-- 也可以导入properties文件 -->
```

```xml
<!--输出到控制台 appender基本格式-->
<appender name="console" class="ch.qos.logback.core.ConsoleAppender">
	<encoder><!-- 输出格式 -->
		<pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} %contextName [%thread] %-5level %logger{36}- %msg%n
        </pattern>
        <charset>utf-8</charset>
	</encoder>
</appender>
```

```xml
<!--输出到文件 -->
<appender name="file" class="ch.qos.logback.core.rolling.RollingFileAppender">
   <!-- 如果是 true，日志被追加到文件结尾，如果是false，清空现存文件，默认是true。-->
    <append>true</append>
    <!-- 切分，对日志进行切分  -->
    <!--TimeBasedRollingPolicy 按时间切分 -->
    <!--SizeAndTimeBasedRollingPolicy 按时间和大小切分  必需配置切分的大小-->
	<rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
        <!--配置日志名 ，在按照大小切分时必须用%i标识，区分每天的日志-->
        <fileNamePattern>${log.path}/demo_%d{yyyy-MM-dd}.%i.log</fileNamePattern>
        <maxHistory>60</maxHistory><!-- 只保留最近60天的日志，超过60天的会删除 -->
        <!-- 每天或者每1gb就切分 SizeAndTimeBasedRollingPolicy选这个时候是必须的 -->
        <maxFileSize>2KB</maxFileSize>
    </rollingPolicy>
    <encoder>
        <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} %contextName [%thread] %-5level %logger{36}- %msg%n</pattern>
        <charset>UTF-8</charset>
    </encoder>
</appender>
```

```xml
<!-- 常用的filter-->
<!-- 粗粒度过滤器，只会打印给定级别以上的日志-->
<filter class="ch.qos.logback.classic.filter.ThresholdFilter">
    <level>ERROR</level>
</filter>

<!-- 细粒度过滤器，在某个给定级别下，对个别级别的过滤-->
<!--举例：当前日志打印是info级别的，info会打印info，warn，error三个，但是我不想打印出warn日志，就需要这个过滤器-->
<filter class="ch.qos.logback.classic.filter.LevelFilter">
    <level>WARN</level>
    <onMatch>DENY</onMatch>  <!-- 匹配到就拒绝打印-->
    <onMismatch>ACCEPT</onMismatch>  <!-- 没匹配到就打印-->
</filter>
```

```xml
<!-- 设置根节点的日志级别，在没有指定日志级别的前提下，会默认使用root的日志级别，如果有多个root，只有第一个root会被执行 -->
<root level="info">
    <appender-ref ref="console" />
    <appender-ref ref="file" />
    <appender-ref ref="file-error" />
</root>
```

```xml
<!-- 具体指定某个包或者某个类的日志级别-->
<logger name="com.example" level="debug" />
<!-- 指定某个类采用指定的appender打印日志-->
<!-- additivity="false" 是否向上传递日志信息，默认为true -->
<!-- 上面root里面配置所有appender作为默认日志打印级别，如果不想重复打印日志，只想按照指定方案打印，就需要设置为false-->
<!-- 可以根据需求在不同的包下设置不同的日志打印方案-->
<logger name="com.example.controller.AController" level="info" additivity="false"> 
	<appender-ref ref="demo-controller" />
</logger>
```

## 4、自定义日志样式和颜色
```java
public class LevelColorConfig extends ForegroundCompositeConverterBase<ILoggingEvent> {
    @Override
    protected String getForegroundColorCode(ILoggingEvent event) {
        Level level = event.getLevel();
        switch (level.toInt()) {
            case Level.ERROR_INT:
                return BOLD + RED_FG;
            case Level.WARN_INT:
                return RED_FG;
            case Level.INFO_INT:
                return GREEN_FG;
            case Level.DEBUG_INT:
                return BOLD+BLACK_FG;
            default:
                return DEFAULT_FG;
        }
    }
}
```

```xml
<!--conversionWord 别名 converterClass 自定义的类 -->
<conversionRule conversionWord="levelColor" converterClass="com.bladeono.logback.LevelColorConfig" />
<appender name="color" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
        <pattern>[%thread] - %levelColor(%-5level) - %msg%n</pattern>
    </encoder>
</appender>
```

```java
public class MySampleConverter extends ClassicConverter {

  long start = System.nanoTime();

  @Override
  public String convert(ILoggingEvent event) {
    long nowInNanos = System.nanoTime();
    return Long.toString(nowInNanos-start);
  }
}
```

```xml
<conversionRule conversionWord="nanos" 
                converterClass="com.bladeono.logback.MySampleConverter" />

<appender name="self" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
        <pattern>%-6nanos [%thread] - %msg%n</pattern>
    </encoder>
</appender>
```

## 5、与`SpringBoot`整合

如果需要`SpringBoot`的配置文件中的参数，那么就需要跟`SpringBoot`进行整合，由于logback.xml文件会在application.yml文件加载前就加载，这样就获取不到application.yml的配置。所以需要把logback.xml改成logback-spring.xml。另外，多环境下需要不同的日志打印，也需要将不同环境和日志分开。`SpringBoot`扩展主要有两个标签

```xml
<springProfile name="test">
	<!-- 测试下才会执行-->
</springProfile>
<springProfile name="dev | test">
	<!-- 测试环境或者开发环境 -->
</springProfile>
<springProfile name="!production">
	<!--非生产环境下的配置-->
</springProfile>
```

```xml
<!--当我们需要获取application.yml中的配置时，就需要springProperty,其中的source是对应application配置的key，name为别名，defaultValue：如果没有这个key就用这个默认值。scope是这个变量的作用域-->
<!--
local :在配置文件内有效，
context :在logger context中有效
system : 整个JVM 内都有效；
logback 在替换变量时，首先搜索 local 变量，然后搜索 context，最后搜索 system
-->
<springProperty scope="context" name="app" source="spring.application.name"
		defaultValue="myapp"/>
```


