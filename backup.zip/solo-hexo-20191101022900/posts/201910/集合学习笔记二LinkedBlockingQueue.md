title: 集合学习笔记(二)—LinkedBlockingQueue
date: '2019-10-10 19:55:43'
updated: '2019-10-10 19:55:58'
tags: [Queue]
permalink: /articles/2019/10/10/1570708543427.html
---

### 1.成员变量

```java
// 容量，如果创建对象的时候没有指定，那么将使用Integer.MAX_VALUE
private final int capacity;
//当前队列中元素个数，原子类保证个数的增减是原子性
private final AtomicInteger count = new AtomicInteger();
//取锁
private final ReentrantLock takeLock = new ReentrantLock();
//取锁的条件
private final Condition notEmpty = takeLock.newCondition();
//插入锁
private final ReentrantLock putLock = new ReentrantLock();
//插入锁条件
private final Condition notFull = putLock.newCondition();
/*
	分析：这里将插入和取出分别用两个锁目的是为了提高存取效率。
		 本身队列由链表结构实现，尾插入，头取出，可
*/
//头结点，头结点只保存下一个结点的地址
transient Node<E> head;
//尾结点，last.next一定为null
private transient Node<E> last;

```

### 2.构造方法

```java
public LinkedBlockingQueue() {
    this(Integer.MAX_VALUE);
}
//初始化队列大小，并初始化头结点和尾结点
public LinkedBlockingQueue(int capacity) {
    if (capacity <= 0) throw new IllegalArgumentException();
    this.capacity = capacity;
    last = head = new Node<E>(null);
}
//根据给定的一个集合创建队列，
public LinkedBlockingQueue(Collection<? extends E> c) {
    this(Integer.MAX_VALUE);
    final ReentrantLock putLock = this.putLock;
    putLock.lock(); // Never contended, but necessary for visibility 虽然没有争抢锁
    //但是对于阅读还是有必要的
    try {
        int n = 0;
        for (E e : c) {
            if (e == null)
                throw new NullPointerException();
            if (n == capacity)
                throw new IllegalStateException("Queue full");
            enqueue(new Node<E>(e));
            ++n;
        }
        count.set(n);
    } finally {
        putLock.unlock();
    }
}

```

### 3.公共方法

#### 1.入队

```JAVA
//获取队列中元素个数
public int size() {
	return count.get();
}
//非原子性操作获取剩余空间。
public int remainingCapacity() {
    return capacity - count.get();
}
//新增元素，如果队列满了会一直阻塞等待。
public void put(E e) throws InterruptedException {
    if (e == null) throw new NullPointerException();
    int c = -1;
    Node<E> node = new Node<E>(e);
    final ReentrantLock putLock = this.putLock;
    final AtomicInteger count = this.count;
    putLock.lockInterruptibly();//获取锁，获取不到就等待，可以被打断。
    try {
        /*源码对count使用的解释：
        	这里的count只用来判断队列是否满了，需要等待，而且在做这个判断的时候
        	所有的插入线程都已经被阻塞，意味着，count只可能减小。
        	所以即使对count不加锁也不会出现问题。
        	其他方法的count作用类似。
        */
        while (count.get() == capacity) {//如果队列满了，阻塞等待
            notFull.await();
        }
        enqueue(node);
        c = count.getAndIncrement();//队列元素加一，返回插入之前的值
        if (c + 1 < capacity)//如果队列没满
            notFull.signal();//唤醒等待添加元素的一个线程
    } finally {
        putLock.unlock();
    }
    if (c == 0)//如果插入前队列为空，那么唤醒等待的取元素线程
        signalNotEmpty();
}
//新增元素
public boolean offer(E e) {
        if (e == null) throw new NullPointerException();
        final AtomicInteger count = this.count;
        if (count.get() == capacity)//如果队列满了，会直接返回插入失败
            return false;
        int c = -1;
        Node<E> node = new Node<E>(e);
        final ReentrantLock putLock = this.putLock;
        putLock.lock();//抢锁
        try {
            if (count.get() < capacity) {//抢到锁之后判断下队列是否满了
                enqueue(node);
                c = count.getAndIncrement();
                if (c + 1 < capacity)//如果插入之后队列还是没满，唤醒插入元素的线程
                    notFull.signal();
            }
        } finally {
            putLock.unlock();
        }
        if (c == 0)//如果插入之前队列为空，那么唤醒取元素的线程
            signalNotEmpty();
        return c >= 0;//try中出了异常等情况导致c的值没有被更新，还是负的时候返回false插入失败
    }
//插入，在给定时间内阻塞等待，时间过了则插入失败
public boolean offer(E e, long timeout, TimeUnit unit)
        throws InterruptedException {

        if (e == null) throw new NullPointerException();
        long nanos = unit.toNanos(timeout);//把时间统一转换成纳秒单位
        int c = -1;
        final ReentrantLock putLock = this.putLock;
        final AtomicInteger count = this.count;
        putLock.lockInterruptibly();//获取锁(等锁的过程可以被打断)
        try {
            while (count.get() == capacity) {//队列满了
                if (nanos <= 0)//如果等待时间小于等于0 返回插入失败
                    return false;
                nanos = notFull.awaitNanos(nanos);//等待指定时间，返回估计的剩余等待时间
            }
            //上面这段代码是调用awaitNanos()的标准格式，也是等待一定时长的标准代码
            enqueue(new Node<E>(e));
            c = count.getAndIncrement();
            if (c + 1 < capacity)
                notFull.signal();
        } finally {
            putLock.unlock();
        }
        if (c == 0)
            signalNotEmpty();
        return true;
    }
//插入，只要队列没满就竞争锁插入，如果队列满了直接返回fasle
//源码提示，这个方法要比BlockingQueue的add更好，add在队列满了的时候会抛出异常，而这个只会返回false
public boolean offer(E e) {
        if (e == null) throw new NullPointerException();
        final AtomicInteger count = this.count;
        if (count.get() == capacity)
            return false;
        int c = -1;
        Node<E> node = new Node<E>(e);
        final ReentrantLock putLock = this.putLock;
        putLock.lock();
        try {
            if (count.get() < capacity) {//抢到锁之后再判断一次(双重检查思想)
                enqueue(node);
                c = count.getAndIncrement();
                if (c + 1 < capacity)
                    notFull.signal();
            }
        } finally {
            putLock.unlock();
        }
        if (c == 0)
            signalNotEmpty();
        return c >= 0;
    }
//查看队列头元素
 public E peek() {
        if (count.get() == 0)//如果队列为空直接返回null
            return null;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lock();//抢锁
        try {
            Node<E> first = head.next;
            if (first == null)//这里再判断一次队列是否为空，用if (count.get() == 0)也可以。
                return null;
            else
                return first.item;
        } finally {
            takeLock.unlock();
        }
    }
```



#### 2.出队

```java
public E take() throws InterruptedException {
        E x;
        int c = -1;
        final AtomicInteger count = this.count;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lockInterruptibly();
        try {
            while (count.get() == 0) {//与put()方法是一对，队列为空就无限等待
                notEmpty.await();
            }
            x = dequeue();
            c = count.getAndDecrement();
            if (c > 1)//如果出队前队列元素大于1，就唤醒一个出队线程继续出队
                notEmpty.signal();
        } finally {
            takeLock.unlock();
        }
        if (c == capacity)//如果出队前队列是满的，那么就唤醒一个入队线程
            signalNotFull();
        return x;
    }
//如果队列为空，那么在给定时间内等待出队，超过时间返回null
public E poll(long timeout, TimeUnit unit) throws InterruptedException {
        E x = null;
        int c = -1;
        long nanos = unit.toNanos(timeout);
        final AtomicInteger count = this.count;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lockInterruptibly();
        try {
            while (count.get() == 0) {
                if (nanos <= 0)
                    return null;
                nanos = notEmpty.awaitNanos(nanos);
            }
            x = dequeue();
            c = count.getAndDecrement();
            if (c > 1)
                notEmpty.signal();
        } finally {
            takeLock.unlock();
        }
        if (c == capacity)
            signalNotFull();
        return x;
    }
//如果队列为空直接返回null，否则竞争出队锁
 public E poll() {
        final AtomicInteger count = this.count;
        if (count.get() == 0)
            return null;
        E x = null;
        int c = -1;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lock();
        try {
            if (count.get() > 0) {//抢到锁之后再判断一次
                x = dequeue();
                c = count.getAndDecrement();
                if (c > 1)
                    notEmpty.signal();
            }
        } finally {
            takeLock.unlock();
        }
        if (c == capacity)
            signalNotFull();
        return x;
    }
```

#### 3.操作指定的某个元素

```java
//删除指定元素 trail->翻译 跟踪，踪迹
public boolean remove(Object o) {
        if (o == null) return false;//如果传入参数为空直接返回false
        fullyLock();//删除元素的时候入队和出队锁全加上
        try {
            //遍历队列中所有的结点，如果找到指定的元素就删除并返回true否则返回false
            for (Node<E> trail = head, p = trail.next;
                 p != null;
                 trail = p, p = p.next) {
                if (o.equals(p.item)) {
                    unlink(p, trail);
                    return true;
                }
            }
            return false;
        } finally {
            fullyUnlock();
        }
    }
//查找指定元素是否在队列里
 public boolean contains(Object o) {
        if (o == null) return false;
        fullyLock();
        try {
            for (Node<E> p = head.next; p != null; p = p.next)
                if (o.equals(p.item))
                    return true;
            return false;
        } finally {
            fullyUnlock();
        }
    }

//取消内部节点p与前驱路径的链接
void unlink(Node<E> p, Node<E> trail) {
//调用这个方法必须保证已经同时加了入队和出队锁
        p.item = null;//把p的内容置空
        trail.next = p.next;//前驱结点的next指向p结点的next
        if (last == p)//如果p就是尾结点，那么把前驱结点赋值给尾结点标记
            last = trail;
        if (count.getAndDecrement() == capacity)//队列元素减1如果删除前队列是满的，
            //那么唤醒一个入队线程
            notFull.signal();
    }
```

#### 4.转换数组

```java
//队列转数组，api提示：队列不会保留对该数组的引用；可以用来作为数组和集合转换的桥梁 
public Object[] toArray() {
        fullyLock();
        try {
            int size = count.get();
            Object[] a = new Object[size];//新建一个数组返回，保证是安全的，可以修改的
            int k = 0;
            for (Node<E> p = head.next; p != null; p = p.next)
                a[k++] = p.item;
            return a;
        } finally {
            fullyUnlock();
        }
    }
//队列转到给定数组中
public <T> T[] toArray(T[] a) {
        fullyLock();
        try {
            int size = count.get();
            if (a.length < size)//先判断传入的数组大小是否能包含队列全部元素
                a = (T[])java.lang.reflect.Array.newInstance
                    (a.getClass().getComponentType(), size);
				//如果传入数组小于队列元素总数，那么反射创建一个新数组
            int k = 0;
            for (Node<E> p = head.next; p != null; p = p.next)
                a[k++] = (T)p.item;
            if (a.length > k)//队列元素都插入数组之后判断如果数组长度大于队列元素
                //就把队列元素个数+1的值赋值为null
                a[k] = null;
            return a;
        } finally {
            fullyUnlock();
        }
    }
```

#### 5.toString()

```java
public String toString() {
        fullyLock();
        try {
            Node<E> p = head.next;//头结点next为空，队列为空返回空
            if (p == null)
                return "[]";

            StringBuilder sb = new StringBuilder();
            sb.append('[');
            for (;;) {
                E e = p.item;
                sb.append(e == this ? "(this Collection)" : e);
                //如果没有使用泛型而直接把本身加进队列，就会打印this collection
                //集合的toString()都是相同实现
                p = p.next;
                if (p == null)
                    return sb.append(']').toString();
                sb.append(',').append(' ');
            }
        } finally {
            fullyUnlock();
        }
    }
```

#### 6.clear()

```java
 public void clear() {
        fullyLock();
        try {
            for (Node<E> p, h = head; (p = h.next) != null; h = p) {
                h.next = h;//引用自身来释放对其他结点的引用
                p.item = null;//内容置空
            }
            head = last;
            if (count.getAndSet(0) == capacity)//如果清空前队列是满的，那么唤醒入队线程
                notFull.signal();
        } finally {
            fullyUnlock();
        }
    }
```

#### 7.drainTo()

```java
//移除指定个数的队列元素，并把移除的元素添加到指定的集合中
public int drainTo(Collection<? super E> c, int maxElements) {
    if (c == null)
        throw new NullPointerException();
    if (c == this)
        throw new IllegalArgumentException();
    if (maxElements <= 0)
        return 0;
    boolean signalNotFull = false;
    final ReentrantLock takeLock = this.takeLock;
    takeLock.lock();
    try {
        int n = Math.min(maxElements, count.get());//判断队列元素个数和指定数大小，取小的一个
        Node<E> h = head;
        int i = 0;
        try {
            while (i < n) {//循环出队并添加到集合中
                Node<E> p = h.next;
                c.add(p.item);
                p.item = null;
                h.next = h;
                h = p;
                ++i;
            }
            return n;//返回出队个数/集合中添加的元素个数
        } finally {
            // 重新设置头结点和当前队列元素个数，放在finally保证add抛出异常也能执行。
            if (i > 0) {
                // assert h.item == null;
                head = h;
                signalNotFull = (count.getAndAdd(-i) == capacity);
            }
        }
    } finally {
        takeLock.unlock();
        if (signalNotFull)
            signalNotFull();
    }
}
```



### 4.私有方法

```java
//唤醒一个等待取元素的线程
private void signalNotEmpty() {
    final ReentrantLock takeLock = this.takeLock;
    takeLock.lock();
    try {
        notEmpty.signal();
    } finally {
        takeLock.unlock();
    }
}
//唤醒一个等待插入元素的线程
private void signalNotFull() {
    final ReentrantLock putLock = this.putLock;
    putLock.lock();
    try {
        notFull.signal();
    } finally {
        putLock.unlock();
    }
}
//从队尾插入一个元素
private void enqueue(Node<E> node) {
    // assert putLock.isHeldByCurrentThread();
    // assert last.next == null;
    last = last.next = node;
    //把新元素赋给当前尾结点的next，然后把当前尾结点的next重新赋值给last
}
//从队头删除一个元素
private E dequeue() {
    // assert takeLock.isHeldByCurrentThread();
    // assert head.item == null;
    Node<E> h = head;
    Node<E> first = h.next;
    h.next = h; // help GC 指向自己，释放对其他对象的引用，可以让gc更快的回收
    head = first;
    E x = first.item;
    first.item = null;
    return x;
}

```

### 5.迭代器

```java

//迭代器采用弱一致性，在创建迭代器对象的时候把当前头结点记录下来，之后如果有结点出队也不会被知道。
//除非再次创建实例
//所以迭代器并不安全，如果队列只有一个元素，一个线程创建了iterator，准备遍历并删除，
//而另一个元素直接poll那么迭代器线程大概率抛异常，(弱一致性导致)防止这种情况需要在调用的时候对队列再加锁。

private class Itr implements Iterator<E> {

    private Node<E> current;
    private Node<E> lastRet;
    private E currentElement;

    Itr() {
        //加锁原因，如果队列只有一个结点，正在初始化迭代器的时候这个结点被出队了导致抛异常。
        fullyLock();
        try {
            current = head.next;//初试化的时候让current持有第一个节点
            if (current != null)
                currentElement = current.item;
        } finally {
            fullyUnlock();
        }
    }

    public boolean hasNext() {
        return current != null;
    }


    private Node<E> nextNode(Node<E> p) {
        for (;;) {
            Node<E> s = p.next;
            if (s == p)//表明原来记录的第一个结点已经出队了
                return head.next;
            //如果s为空说明传入的是尾结点，nextCode就返回空
            //如果s不为空但是值为空，那么就继续遍历下一个节点
            if (s == null || s.item != null)
                return s;
            p = s;
        }
    }

    public E next() {
        fullyLock();//加锁防止遍历结点的时候出现结构改变
        try {
            if (current == null)
                throw new NoSuchElementException();
            E x = currentElement;
            lastRet = current;//把当前指针走到的节点记录下来。
            current = nextNode(current);
            currentElement = (current == null) ? null : current.item;
            return x;
        } finally {
            fullyUnlock();
        }
    }

    public void remove() {
        if (lastRet == null)
            throw new IllegalStateException();
        fullyLock();//加全锁防止在删除元素期间出现问题
        try {
            Node<E> node = lastRet;
            lastRet = null;
            for (Node<E> trail = head, p = trail.next;
                 p != null;
                 trail = p, p = p.next) {
                if (p == node) {
                    unlink(p, trail);
                    break;
                }
            }
        } finally {
            fullyUnlock();
        }
    }
}

```


