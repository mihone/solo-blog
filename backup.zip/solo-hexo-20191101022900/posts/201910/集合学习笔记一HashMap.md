title: 集合学习笔记(一)—HashMap
date: '2019-10-10 07:34:11'
updated: '2019-10-10 07:34:11'
tags: [HashMap]
permalink: /articles/2019/10/10/1570664051457.html
---
# 集合学习笔记(一)—HashMap

## 一、与hashtable区别

#### 1.非线程安全的

#### 2.允许null的key和null的value

## 二、基本介绍

#### 1.不保证排序，也不保证排序好的键值对的顺序不会改变。

#### 2.如果需要迭代器遍历的情况，最好不要把HashMap的容量设的太高或者把加载因子设置的太低

&emsp;&emsp;解释:查看iterator部分源码

```java
final class KeyIterator extends HashIterator
        implements Iterator<K> {
        public final K next() { return nextNode().key; }
    }
final Node<K,V> nextNode() {
            Node<K,V>[] t;
            Node<K,V> e = next;
            if (modCount != expectedModCount)
                throw new ConcurrentModificationException();
            if (e == null)
                throw new NoSuchElementException();
                //这里如果出现了结点值为null但是桶数组不为空的情况，那么就会遍历桶数组直到找到下一个
                //不为空的头结点。如果桶数组太大，就会增加找下一个节点的时间。而加载因子太小，很快扩容，导致实际存在桶内键值对只占50%的位置，增加遍历时间。
            if ((next = (current = e).next) == null && (t = table) != null) {
                do {} while (index < t.length && (next = t[index++]) == null);
            }
            return e;
        }
```



#### 3.默认初始大小16，加载因子0.75

#### 4.存的键值对多的情况下，初始化一个大一点的map要比让map扩容更加的效率

#### 5.fail-fast

&emsp;&emsp;fail-fast产生的原因就在于程序在对 `collection` 进行迭代时，某个线程对该 `collection` 在结构上对其做了修改，这时迭代器就会抛出 `ConcurrentModificationException` 异常信息，从而产生 `fail-fast`。而判断结构是否有更改的标志就是`modCount`。

&emsp;&emsp;所有的`foreach`遍历，`replaceAll`都会出现fail-fast。

## 三、成员变量

```java
//默认初始大小16
static final int DEFAULT_INITIAL_CAPACITY = 1 << 4
//最大容量
static final int MAXIMUM_CAPACITY = 1 << 30;
//默认的加载因子0.75
static final float DEFAULT_LOAD_FACTOR = 0.75f;
//链表结构转红黑树结构的阈值
static final int TREEIFY_THRESHOLD = 8;
//红黑树转链表的阈值
static final int UNTREEIFY_THRESHOLD = 6;
//可以树形化时的最小容量，否则会选择扩容而不是链表转树。该值最小为4倍的TREEIFY_THRESHOLD
static final int MIN_TREEIFY_CAPACITY = 64;
//用来缓存entrySet()的结果，AbstractMap将它用于keySet()和values()
transient Set<Map.Entry<K,V>> entrySet;
//map结构发生变化的次数。用来在iterator迭代时可以快速失败的标志
transient int modCount;
//加载因子
final float loadFactor;
//下一次需要扩容时的大小，计算方式：容量*加载因子
int threshold;
//键值对个数
transient int size;
//用来存键值对的结点
transient Node<K,V>[] table;
```

## 四、方法

### 1.哈希桶数组位置以及hash()

&emsp;&emsp;首先从HashMap的结构说起，HashMap基本是由数组加链表组成，根据计算得到的hash分配数组中的位置，如果hash相同，那么在数组相同位置用链表，即链地址法。

&emsp;&emsp;而Object.hashcode()返回的是一个int类型整数，int的范围很大，虽然很难出现碰撞，但是如果key的hash比较分散的话，需要非常大的数组，很占空间。但是如果数组比较小，比如初始只有16，那么再好的hash也会出现大量碰撞。综合考虑时间和空间的效率，HashMap给出了下面的hash()

```java
/*
	hashCode右移16位，正好是32bit的一半。与自己本身做异或操作。混合哈希值的高位和地位，保证高位和地位都能参与运算，增加低位的随机性。并且混合后的值也变相保持了高位的特征。
	
*/
static final int hash(Object key) {
    int h;
    return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
}
```

计算出hash后，决定数组位置的是下面这个方法

```java
//jdk1.7的源码，jdk1.8没有这个方法，但是实现原理一样的
static int indexFor(int h, int length) {  
     return h & (length-1);  //第三步 取模运算
}
```

&emsp;这个方法很巧妙，它通过h & (table.length -1)来得到该对象的保存位，而HashMap底层数组的长度总是2的n次方，这是HashMap在速度上的优化。当length总是2的n次方时，h& (length-1)运算等价于对length取模，也就是h%length，但是&比%具有更高的效率。

### 2.构造方法

```java
//核心构造方法
public HashMap(int initialCapacity, float loadFactor) {
    if (initialCapacity < 0)
    	throw new IllegalArgumentException("Illegal initial capacity: " + initialCapacity);
    if (initialCapacity > MAXIMUM_CAPACITY)
    	initialCapacity = MAXIMUM_CAPACITY;
    if (loadFactor <= 0 || Float.isNaN(loadFactor))
    	throw new IllegalArgumentException("Illegal load factor: " + loadFactor);
    this.loadFactor = loadFactor;
    this.threshold = tableSizeFor(initialCapacity);
}
//最后一行有个tableSizeFor，用来计算hash桶数组的大小
/*
	首先明确的是HashMap的hash桶数组的大小一定是2的n次幂。
	2的n次幂对应的二进制一定是1开头后面全是0，那么2的n次幂减1一定是全部由1组成。
	其次可以明确的是2进制一定是1开头。
	int类型有4字节一共32位，通过将二进制数右移再做|运算，保证右边的位会不断通过或运算变成1
	总共移动32位保证int类型的所有位都进行或运算。
*/
static final int tableSizeFor(int cap) {
    int n = cap - 1;//防止cap为2的n次幂导致数组扩大一倍
    n |= n >>> 1;
    n |= n >>> 2;
    n |= n >>> 4;
    n |= n >>> 8;
    n |= n >>> 16;
    return (n < 0) ? 1 : (n >= MAXIMUM_CAPACITY) ? MAXIMUM_CAPACITY : n + 1;
}
//创建HashMap的时候传入一个map，会调用该方法把传入map的键值对put到新map中
final void putMapEntries(Map<? extends K, ? extends V> m, boolean evict) {
        int s = m.size();
        if (s > 0) {
            if (table == null) { 
                float ft = ((float)s / loadFactor) + 1.0F;
                int t = ((ft < (float)MAXIMUM_CAPACITY) ?
                         (int)ft : MAXIMUM_CAPACITY);
                if (t > threshold)
                    threshold = tableSizeFor(t);
            }
            else if (s > threshold)
                resize();
            for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
                K key = e.getKey();
                V value = e.getValue();
                putVal(hash(key), key, value, false, evict);
            }
        }
    }


```

### 3.get系列方法

```java
//根据key获取值
public V get(Object key) {
        Node<K,V> e;
        return (e = getNode(hash(key), key)) == null ? null : e.value;
}
//判断是否包含某个key
public boolean containsKey(Object key) {
    return getNode(hash(key), key) != null;
}

//get系列核心方法
final Node<K,V> getNode(int hash, Object key) {
    Node<K,V>[] tab; Node<K,V> first, e; int n; K k;
    if ((tab = table) != null && (n = tab.length) > 0 &&
        (first = tab[(n - 1) & hash]) != null) {//这里就运用上面说的hash跟长度取模
        if (first.hash == hash && // always check first node
            ((k = first.key) == key || (key != null && key.equals(k))))
            //如果桶内的头结点就是要找的，那么直接返回头结点
            return first;
        if ((e = first.next) != null) {
            if (first instanceof TreeNode)//如果下一个结点是树节点，说明是红黑树结构，
                return ((TreeNode<K,V>)first).getTreeNode(hash, key);
            do {//否则遍历链表找
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k))))//允许key为空
                    return e;
            } while ((e = e.next) != null);
        }
    }
    return null;
}

```

### 4.put系列方法

```java
//放入键值对
public V put(K key, V value) {
	return putVal(hash(key), key, value, false, true);
}

//put核心方法 onlyIfAbsent：如果true不会改变现有的值 
//evict:在linkedhashmap有用，决定是按照元素put顺序还是访问顺序排序。
//返回旧值(没有旧值就返回null)
final V putVal(int hash, K key, V value, boolean onlyIfAbsent,
               boolean evict) {
    Node<K,V>[] tab; Node<K,V> p; int n, i;
    if ((tab = table) == null || (n = tab.length) == 0)
        n = (tab = resize()).length;//如果桶空的或者长度为0就扩容
    if ((p = tab[i = (n - 1) & hash]) == null)//如果计算桶位置后这个位置为空，
        tab[i] = newNode(hash, key, value, null);//就创建头结点
    else {//不为空
        Node<K,V> e; K k;
        if (p.hash == hash &&
            ((k = p.key) == key || (key != null && key.equals(k))))
            e = p;//如果头结点就是要找的，就把头结点赋值给e
        else if (p instanceof TreeNode)//如果头结点是树结点，就调用putTreeVal
            e = ((TreeNode<K,V>)p).putTreeVal(this, tab, hash, key, value);
        else {//否则说明桶里装的的链表
            for (int binCount = 0; ; ++binCount) {
                if ((e = p.next) == null) {//如果p.next为空说明链表遍历结束也没有key
                    //需要在后面新加入一个结点
                    p.next = newNode(hash, key, value, null);
                    if (binCount >= TREEIFY_THRESHOLD - 1)// 结点创建完之后判断需不需要转换结构
                        // -1是因为binCount从0开始计算的，
                        treeifyBin(tab, hash);
                    break;
                }
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k))))
                    break;//如果判断key相等，说明有这个key，break
                p = e;
            }
        }
        if (e != null) { // 说明key存在
            V oldValue = e.value;
            if (!onlyIfAbsent || oldValue == null)
                e.value = value;
            afterNodeAccess(e);//空实现
            return oldValue;
        }
    }
    ++modCount;//因为前面判断桶位置为空，所以要新创建链表，故这里结构标识++
    if (++size > threshold)//size+1后判断是否需要resize
        resize();
    afterNodeInsertion(evict);//空实现
    return null;
}
```

### 5.扩容

```java
//
final Node<K,V>[] resize() {
    Node<K,V>[] oldTab = table;
    int oldCap = (oldTab == null) ? 0 : oldTab.length;
    int oldThr = threshold;
    int newCap, newThr = 0;
    if (oldCap > 0) {
        if (oldCap >= MAXIMUM_CAPACITY) {//如果旧的桶的大小
            threshold = Integer.MAX_VALUE;//把扩容界限变成int最大值
            return oldTab;//直接返回原来的桶数组
        }
        else if ((newCap = oldCap << 1) < MAXIMUM_CAPACITY &&
                 oldCap >= DEFAULT_INITIAL_CAPACITY)
            //如果旧容量大于默认的并且扩容后也小于最大容量
            newThr = oldThr << 1; // double threshold
    }
    else if (oldThr > 0) // initial capacity was placed in threshold
        newCap = oldThr;
    else {               // zero initial threshold signifies using defaults
        newCap = DEFAULT_INITIAL_CAPACITY;
        newThr = (int)(DEFAULT_LOAD_FACTOR * DEFAULT_INITIAL_CAPACITY);
    }
    if (newThr == 0) {
        float ft = (float)newCap * loadFactor;
        newThr = (newCap < MAXIMUM_CAPACITY && ft < (float)MAXIMUM_CAPACITY ?
                  (int)ft : Integer.MAX_VALUE);
    }
    threshold = newThr;
    @SuppressWarnings({"rawtypes","unchecked"})
    Node<K,V>[] newTab = (Node<K,V>[])new Node[newCap];
    table = newTab;
    if (oldTab != null) {
        for (int j = 0; j < oldCap; ++j) {
            Node<K,V> e;
            if ((e = oldTab[j]) != null) {
                oldTab[j] = null;
                if (e.next == null)//如果桶里只有一个结点
                    newTab[e.hash & (newCap - 1)] = e;//重新计算hash放到新桶中
                else if (e instanceof TreeNode)//如果是树结点，调用树方法
                    ((TreeNode<K,V>)e).split(this, newTab, j, oldCap);
                else { // 表明为链表结构
                    Node<K,V> loHead = null, loTail = null;//这一组用来放不移动的结点
                    Node<K,V> hiHead = null, hiTail = null;//这一组用来放需要移动的结点
                    Node<K,V> next;
                    do {
                        next = e.next;
                        if ((e.hash & oldCap) == 0) {
                            //将现在的hash和旧容量做或运算，结果只可能是oldCap或者0
                            if (loTail == null)
                                loHead = e;
                            else
                                loTail.next = e;
                            loTail = e;
                        }
                        else {
                            if (hiTail == null)
                                hiHead = e;
                            else
                                hiTail.next = e;
                            hiTail = e;
                        }
                    } while ((e = next) != null);
                    if (loTail != null) {
                        loTail.next = null;
                        newTab[j] = loHead;
                    }
                    if (hiTail != null) {
                        hiTail.next = null;
                        newTab[j + oldCap] = hiHead;//当前桶位置+旧容量为新桶位置
                    }
                }
            }
        }
    }
    return newTab;
}
```



### 6.链表转树

```java
//入参，桶数组，最后加入的key的hash
final void treeifyBin(Node<K,V>[] tab, int hash) {
        int n, index; Node<K,V> e;
    //如果桶容量低于64，那么进行扩容而不是链表转树
        if (tab == null || (n = tab.length) < MIN_TREEIFY_CAPACITY)
            resize();
    //要转树的桶内不为空
        else if ((e = tab[index = (n - 1) & hash]) != null) {
            TreeNode<K,V> hd = null, tl = null;
            //这一段循环是把链表结点重新转成树结点后，保留原结点的结构和顺序
            do {
                TreeNode<K,V> p = replacementTreeNode(e, null);//结点转成树结点
                if (tl == null)
                    hd = p;
                else {
                    p.prev = tl;
                    tl.next = p;
                }
                tl = p;
            } while ((e = e.next) != null);
            if ((tab[index] = hd) != null)
                hd.treeify(tab);//转树
        }
    }

```

### 7.clear

```java
//清空桶数组
public void clear() {
    Node<K,V>[] tab;
    modCount++;
    if ((tab = table) != null && size > 0) {
        size = 0;
        for (int i = 0; i < tab.length; ++i)
            tab[i] = null;
    }
}
```

### 8.containsValue

```java
//因为链表转树的时候会在树结点保留一份原来链表的结构，所以这里直接next遍历就行
public boolean containsValue(Object value) {
    Node<K,V>[] tab; V v;
    if ((tab = table) != null && size > 0) {
        for (int i = 0; i < tab.length; ++i) {
            for (Node<K,V> e = tab[i]; e != null; e = e.next) {
                if ((v = e.value) == value ||
                    (value != null && value.equals(v)))
                    return true;
            }
        }
    }
    return false;
}
```

### 9.compute

```java
/*
	找key->找到了->旧值不为空->返回
	找key->找到了->旧值为空->新值不为空->覆盖
	找key->没找到->新值不为空->新增
	(如果新值为空会直接放弃覆盖或者添加。)
*/
public V computeIfAbsent(K key,
                         Function<? super K, ? extends V> mappingFunction) {
    if (mappingFunction == null)
        throw new NullPointerException();
    int hash = hash(key);
    Node<K,V>[] tab; Node<K,V> first; int n, i;
    int binCount = 0;
    TreeNode<K,V> t = null;
    Node<K,V> old = null;
    if (size > threshold || (tab = table) == null ||
        (n = tab.length) == 0)
        n = (tab = resize()).length;
    if ((first = tab[i = (n - 1) & hash]) != null) {//如果这个key对应的桶不为空
        if (first instanceof TreeNode)//如果是树结点，从树中获取
            old = (t = (TreeNode<K,V>)first).getTreeNode(hash, key);
        else {
            Node<K,V> e = first; K k;
            do {//遍历链表找key
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k)))) {
                    old = e;
                    break;
                }
                ++binCount;
            } while ((e = e.next) != null);
        }
        V oldValue;
        if (old != null && (oldValue = old.value) != null) {
            //如果能找到key并且key的值不为空，那么直接返回
            afterNodeAccess(old);
            return oldValue;
        }
    }
    V v = mappingFunction.apply(key);//根据接口函数得到value
    if (v == null) {//如果value为空直接返回，不添加不修改
        return null;
    } else if (old != null) {//如果能找到key但是key的值为空
        old.value = v;
        afterNodeAccess(old);
        return v;
    }
    else if (t != null)//找不到key但发现首结点是树结点
        t.putTreeVal(this, tab, hash, key, v);
    else {//链表
        tab[i] = newNode(hash, key, v, first);
        if (binCount >= TREEIFY_THRESHOLD - 1)
            treeifyBin(tab, hash);
    }
    ++modCount;
    ++size;
    afterNodeInsertion(true);
    return v;
}

/*
	找key->没找到->返回null
	找key->找到了->旧值为空->返回null
	找key->找到了->旧值不为空新值为空->删了
	找key->找到了->都不为空->覆盖

*/
public V computeIfPresent(K key,
                          BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
    if (remappingFunction == null)
        throw new NullPointerException();
    Node<K,V> e; V oldValue;
    int hash = hash(key);
    if ((e = getNode(hash, key)) != null &&
        (oldValue = e.value) != null) {//根据key获取结点，如果有结点并且节点不为空
        V v = remappingFunction.apply(key, oldValue);
        if (v != null) {//如果新的value不为空，那么赋值
            e.value = v;
            afterNodeAccess(e);
            return v;
        }
        else//为空直接删了
            removeNode(hash, key, null, false, true);
    }
    return null;
}

/*
	找key->找到了->新值不为空，覆盖
	找key->找到了->新值如果空，直接删
	找key->没找到->新值不为空，新增。

*/
@Override
public V compute(K key,
                 BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
    if (remappingFunction == null)
        throw new NullPointerException();
    int hash = hash(key);
    Node<K,V>[] tab; Node<K,V> first; int n, i;
    int binCount = 0;
    TreeNode<K,V> t = null;
    Node<K,V> old = null;
    if (size > threshold || (tab = table) == null ||
        (n = tab.length) == 0)//如果桶数组不存在或者长度0或者已经需要扩容了，那么会先扩容。
        n = (tab = resize()).length;
    if ((first = tab[i = (n - 1) & hash]) != null) {
        if (first instanceof TreeNode)
            old = (t = (TreeNode<K,V>)first).getTreeNode(hash, key);
        else {
            Node<K,V> e = first; K k;
            do {
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k)))) {
                    old = e;
                    break;
                }
                ++binCount;
            } while ((e = e.next) != null);
        }
    }
    V oldValue = (old == null) ? null : old.value;
    V v = remappingFunction.apply(key, oldValue);
    if (old != null) {//如果有这个key
        if (v != null) {//新值不为null就更新
            old.value = v;
            afterNodeAccess(old);
        }
        else//为null就删
            removeNode(hash, key, null, false, true);
    }
    else if (v != null) {//如果不存在key但是新值不为空，那么赋值
        if (t != null)
            t.putTreeVal(this, tab, hash, key, v);
        else {
            tab[i] = newNode(hash, key, v, first);
            if (binCount >= TREEIFY_THRESHOLD - 1)
                treeifyBin(tab, hash);
        }
        ++modCount;
        ++size;
        afterNodeInsertion(true);
    }
    return v;
}

```

### 10.merge

```java
/*
	value：准备做计算的新值(不能为空)
	remappingFunction：对旧值和一个给定的新值做计算，计算后返回。
	找key->找到了->应用函数后的新值不为空->赋值
	找key->找到了->应用函数后的新值为空->删除
	找key->没找到->用value新增
*/
@Override
public V merge(K key, V value,
               BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
    if (value == null)
        throw new NullPointerException();
    if (remappingFunction == null)
        throw new NullPointerException();
    int hash = hash(key);
    Node<K,V>[] tab; Node<K,V> first; int n, i;
    int binCount = 0;
    TreeNode<K,V> t = null;
    Node<K,V> old = null;
    if (size > threshold || (tab = table) == null ||
        (n = tab.length) == 0)
        n = (tab = resize()).length;
    if ((first = tab[i = (n - 1) & hash]) != null) {
        if (first instanceof TreeNode)
            old = (t = (TreeNode<K,V>)first).getTreeNode(hash, key);
        else {
            Node<K,V> e = first; K k;
            do {
                if (e.hash == hash &&
                    ((k = e.key) == key || (key != null && key.equals(k)))) {
                    old = e;
                    break;
                }
                ++binCount;
            } while ((e = e.next) != null);
        }
    }
    if (old != null) {
        V v;
        if (old.value != null)
            v = remappingFunction.apply(old.value, value);
        else
            v = value;
        if (v != null) {
            old.value = v;
            afterNodeAccess(old);
        }
        else
            removeNode(hash, key, null, false, true);
        return v;
    }
    if (value != null) {
        if (t != null)
            t.putTreeVal(this, tab, hash, key, value);
        else {
            tab[i] = newNode(hash, key, value, first);
            if (binCount >= TREEIFY_THRESHOLD - 1)
                treeifyBin(tab, hash);
        }
        ++modCount;
        ++size;
        afterNodeInsertion(true);
    }
    return value;
}
```


