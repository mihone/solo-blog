title: 集合学习笔记(三)—ArrayList、LinkedList、LinkedHashMap
date: '2019-10-10 20:06:59'
updated: '2019-10-21 17:27:33'
tags: [List, HashMap]
permalink: /articles/2019/10/10/1570709218946.html
---

## 一、ArrayList

### 1、快速认识

①  数组结构，非线程安全

②  多线程访问推荐 `Collections.synchronizedList`加锁

③  `fail-fast` `add`，`remove`，`iterator`出现结构变化直接抛异常并退出

④  初始大小10，扩容时候一般为原长度的1.5倍。
```java
ensureCapacity(int mincapacity)
    ->如果数组不为空，进行扩容，扩容后如果小于给定的最小容量，就按照给定的数进行扩容
    ->数组为空，就先比较给定的和默认的10哪个大，给的大再扩容
```

⑤  最大数组大小是`Integer`最大值-8
原因：

```
尝试分配更大的数组可能会导致
OutOfMemoryError：请求的数组大小超过VM限制
```

### 2、方法

#### 1、indexOf/lastIndexOf

```java
public int indexOf(Object o) {
    if (o == null) {//先判断是不是为空，空的话遍历去找第一个空值
        for (int i = 0; i < size; i++)
            if (elementData[i]==null)
                return i;
    } else {//不是空的话遍历找相等的
        for (int i = 0; i < size; i++)
            if (o.equals(elementData[i]))
                return i;
    }
    return -1;
}
//lastIndexOf 从后往前找，其他都一样
```

#### 2、clone

```java
//复制数组元素到一个新数组，元素本身不会克隆
public Object clone() {
    try {
        ArrayList<?> v = (ArrayList<?>) super.clone();
        v.elementData = Arrays.copyOf(elementData, size);
        v.modCount = 0;
        return v;
    } catch (CloneNotSupportedException e) {
        // this shouldn't happen, since we are Cloneable
        throw new InternalError(e);
    }
}
```



#### 3、add/grow

```java
public boolean add(E e) {
    ensureCapacityInternal(size + 1);  //+1是为了判断本次添加后数组是否满了
    elementData[size++] = e;
    return true;
}
private void ensureCapacityInternal(int minCapacity) {
    ensureExplicitCapacity(calculateCapacity(elementData, minCapacity));
}
private void ensureExplicitCapacity(int minCapacity) {
    modCount++;
    if (minCapacity - elementData.length > 0)
        grow(minCapacity);
}
private void grow(int minCapacity) {//先扩容，然后和指定的比较
    int oldCapacity = elementData.length;
    int newCapacity = oldCapacity + (oldCapacity >> 1);
    if (newCapacity - minCapacity < 0)
        newCapacity = minCapacity;
    if (newCapacity - MAX_ARRAY_SIZE > 0)
        newCapacity = hugeCapacity(minCapacity);
    elementData = Arrays.copyOf(elementData, newCapacity);
}
private static int hugeCapacity(int minCapacity) {//判断是否超过上限
    if (minCapacity < 0) 
        throw new OutOfMemoryError();
    return (minCapacity > MAX_ARRAY_SIZE) ?
        Integer.MAX_VALUE :
    MAX_ARRAY_SIZE;
}
```

#### 4、retainAll/removeAll

retainAll用来求两个集合的交集，removeAll除了删除当前集合的元素外，还可以用来求两个集合的补集。求交集或者补集结果保存在调用这两个方法的集合对象中。

```java
public boolean removeAll(Collection<?> c) {
    Objects.requireNonNull(c);
    return batchRemove(c, false);
}
public boolean retainAll(Collection<?> c) {
    Objects.requireNonNull(c);
    return batchRemove(c, true);
}
//complement 补足物；补语；余角
private boolean batchRemove(Collection<?> c, boolean complement) {
    final Object[] elementData = this.elementData;
    int r = 0, w = 0;
    boolean modified = false;
    try {
        for (; r < size; r++)//符合条件的从0号位开始存放
            if (c.contains(elementData[r]) == complement)
                elementData[w++] = elementData[r];
    } finally {
       //只有contain抛异常才会执行这段，
        //把r后面的元素往前移一位。之后再把w后面的都变成空
        if (r != size) {//
            System.arraycopy(elementData, r,
                             elementData, w,
                             size - r);
            w += size - r;
        }
        if (w != size) {//求完交集补集的结果如果不是整个数组，那么把之后的置空让gc可以回收
            for (int i = w; i < size; i++)
                elementData[i] = null;
            modCount += size - w;
            size = w;
            modified = true;
        }
    }
    return modified;
}
```

#### 5、subList

对给定的区间返回一个原list的视图。本质是ArrayList的一个内部类，subList中保留有对原list的印个引用。可以通过sublist对原list操作。**但是如果原list发生改变，那么调用subList的任何增删改方法都会导致抛出异常。**

## 2.LinkedList

LinkedList底层实现实际上就是一个基本的尾进头出的链表。

### 1、快速认识

①  实现了List和Deque接口，允许null元素

②  多线程访问推荐 `Collections.synchronizedList`加锁

③  `fail-fast` `add`，`remove`，`iterator`出现结构变化直接抛异常并退出

### 2、方法

#### 1、add

```java
public boolean add(E e) {
    linkLast(e);
    return true;
}
void linkLast(E e) {
    final Node<E> l = last;
    final Node<E> newNode = new Node<>(l, e, null);
    last = newNode;
    if (l == null)
        first = newNode;
    else
        l.next = newNode;
    size++;
    modCount++;
}
//插入是插到队列尾部
```

#### 2、indexOf/contains

```java
//lastIndexOf就是从后往前找。
public int indexOf(Object o) {
    int index = 0;
    if (o == null) {
        for (Node<E> x = first; x != null; x = x.next) {
            if (x.item == null)
                return index;
            index++;
        }
    } else {
        for (Node<E> x = first; x != null; x = x.next) {
            if (o.equals(x.item))
                return index;
            index++;
        }
    }
    return -1;
}

public boolean contains(Object o) {
    return indexOf(o) != -1;
}
```

3、get

```java
public E get(int index) {
    checkElementIndex(index);
    return node(index).item;
}
//为了加快查询速度，先判断index是在链表的前半还是后半
Node<E> node(int index) {
    if (index < (size >> 1)) {
        Node<E> x = first;
        for (int i = 0; i < index; i++)
            x = x.next;
        return x;
    } else {
        Node<E> x = last;
        for (int i = size - 1; i > index; i--)
            x = x.prev;
        return x;
    }
}

```



## 3.LinkedHashMap

### 1、快速认识

①  继承了HashMap，内部entry新增after和before用来记录顺序。

②  用这个Map可以构建最少使用算法的缓存，构造方法中的`accessOrder` 设为true为开启，按照访问次数排序。

③  访问顺序的map中，get会改变结构。

④  `fail-fast` `add`，`get`,`remove`，`iterator`出现结构变化直接抛异常并退出

⑤  非线程安全，需要`Collections.synchronizedMap`

⑥  头结点为在链表中时间最久(最老)的结点，尾结点为在链表中时间最短(最年轻)的结点

### 2、方法

LinkedHashMap大部分都是继承了HashMap的实现，但是在为了实现有序的map，LinkedHashMap有三个核心的方法afterNodeInsertion，afterNodeAccess，afterNodeRemoval，下面分别来说这三个方法。

#### 1、afterNodeInsertion

```java
//在有插入的情况下最后会调用这个方法，这个参数就是表明是否是插入行为。
void afterNodeInsertion(boolean evict) { 
    LinkedHashMap.Entry<K,V> first;
    if (evict && (first = head) != null && removeEldestEntry(first)) {
        K key = first.key;
        removeNode(hash(key), key, null, false, true);
    }
}
//如果插入后需要移除最老的的元素，那么需要重写这个方法，
//应用场景，比如说缓存满了，需要删除老的元素。
//不推荐在这个方法里面做增删改
//如果需要做增删改，一定要返回false。
protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
    return false;
}
```

#### 2、afterNodeAccess

```java
//访问后调用，把访问过的结点放到链表的最后。
//调用这个的方法有：putVal，replace，computeIfAbsent，computeIfPresent，compute
void afterNodeAccess(Node<K,V> e) { 
    LinkedHashMap.Entry<K,V> last;
    if (accessOrder && (last = tail) != e) {
        LinkedHashMap.Entry<K,V> p =
            (LinkedHashMap.Entry<K,V>)e, b = p.before, a = p.after;
        p.after = null;
        if (b == null)
            head = a;
        else
            b.after = a;
        if (a != null)
            a.before = b;
        else
            last = b;
        if (last == null)
            head = p;
        else {
            p.before = last;
            last.after = p;
        }
        tail = p;
        ++modCount;
    }
}
```

#### 3、afterNodeRemoval

```java
//removeNode后调用，从链表中删掉这个结点。
void afterNodeRemoval(Node<K,V> e) { // unlink
    LinkedHashMap.Entry<K,V> p =
        (LinkedHashMap.Entry<K,V>)e, b = p.before, a = p.after;
    p.before = p.after = null;
    if (b == null)
        head = a;
    else
        b.after = a;
    if (a == null)
        tail = b;
    else
        a.before = b;
}
```

