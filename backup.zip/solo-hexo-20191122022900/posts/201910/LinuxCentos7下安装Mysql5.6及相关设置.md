title: Linux Centos7下安装Mysql5.6及相关设置
date: '2019-10-10 20:13:07'
updated: '2019-10-10 20:13:07'
tags: [Linux, MySQL]
permalink: /articles/2019/10/10/1570709587797.html
---
从CentOS7开始默认的数据库是MariaDB，那么我们在CentOS7就无法安装MySQL数据库了吗。介绍一下在CentOS7上安装MySQL5.6的方法。

### 一、删除mariaDB

```shell
# 确认以安装的MariaDB相关包

yum list installed | grep mariadb

# 删除MariaDB

yum -y remove 查询到的mariaDB
```



### 二、安装mysql

```yaml
# 安装MySQL的yum源
yum -y install http://dev.mysql.com/get/mysql-community-release-el7-5.noarch.rpm

# 安装MySQL
yum -y install mysql mysql-devel mysql-server mysql-utilities

# 启动MySQL
systemctl start mysqld.service

# 确认MySQL版本
mysql -V
```



### 三、登录及必要设置

#### 1.密码

yum安装的mysql用root登录时候，密码是空的，如果需要设置密码，采用以下设置

```yaml
# 使用mysql库
use mysql

#更新root密码(5.6版本mysql)
UPDATE mysql.user SET authentication_string=PASSWORD('密码') where USER='root';
# 5.7版本
UPDATE mysql.user SET authentication_string=PASSWORD('密码') where USER='root';

#刷新权限
flush privileges;
```

#### 2.允许远程连接

```yaml
# 使用mysql库
use mysql
# 允许任意ip对数据库进行任意操作
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'youpassword' WITH GRANT OPTION;
#刷新权限
flush privileges;


```

### 四、关于mysql权限设置的补充

解析这条sql语句

```sql
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'youpassword' WITH GRANT OPTION;
```



#### 1.ALL PRIVILEGES->对数据库的操作权限

```yaml
# 全局管理权限： 
FILE: 在MySQL服务器上读写文件。 
PROCESS: 显示或杀死属于其它用户的服务线程。 
RELOAD: 重载访问控制表，刷新日志等。 
SHUTDOWN: 关闭MySQL服务。
# 数据库/数据表/数据列权限： 
ALTER: 修改已存在的数据表(例如增加/删除列)和索引。 
CREATE: 建立新的数据库或数据表。 
DELETE: 删除表的记录。 
DROP: 删除数据表或数据库。 
INDEX: 建立或删除索引。 
INSERT: 增加表的记录。 
SELECT: 显示/搜索表的记录。 
UPDATE: 修改表中已存在的记录。
# 特别的权限： 
ALL: 允许做任何事(和root一样)。 
USAGE: 只允许登录--其它什么也不允许做。
```

#### 2.对某个数据库或者表的权限限定

```sql
*.*是允许所有库所有表
如果只想限定某个库，使用database.*
指定表的话 database.table
```



#### 3.“%”->限定ip

百分号是匹配所有ip，如果想要限定某个ip，替换百分号为限定的ip即可

#### 4.删除权限

REVOKE 设置的权限 on 库表限定 from 用户
