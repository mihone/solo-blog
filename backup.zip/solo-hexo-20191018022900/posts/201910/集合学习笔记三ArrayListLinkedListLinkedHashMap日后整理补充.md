title: 集合学习笔记(三)—ArrayList、LinkedList、LinkedHashMap（日后整理补充）
date: '2019-10-10 20:06:59'
updated: '2019-10-10 20:07:06'
tags: [List, HashMap]
permalink: /articles/2019/10/10/1570709218946.html
---


## 1、ArrayList

数组结构，非线程安全

多线程访问推荐 Collections.synchronizedList加锁

fail-fast 迭代中出现结构变化直接抛异常并退出

初始大小10

扩容1.5倍原长度

```java
ensureCapacity(int mincapacity)
    ->如果数组不为空，进行扩容，扩容后如果小于给定的最小容量，就按照给定的数进行扩容
    ->数组为空，就先比较给定的和默认的10哪个大，给的大再扩容
```

最大数组大小是Integer最大值-8

原因：

```
尝试分配更大的数组可能会导致
OutOfMemoryError：请求的数组大小超过VM限制
```

方法

indeof

先判断是不是为空，空的话遍历去找第一个空值

不是空的话遍历找相等的

lastindexof

从最后往前找

toArray ->把list转成array 分配一个新的数组

->把list放到指定数组中，如果数组小了，返回新的数组



add

->先把修改标识++

->判断是否超过容量，超过容量需要扩容

->在数组尾部++

removeall 移除指定集合中存在的元素，->求第一个集合的补集

retainall->求交集

sublist

​	->返回一个list的视图。sublist的修改都会反映到原来的list，但是list的增删，在调用sublist会导致异常

replaceall 代替全部，传一个function 

## 2.linkedlist

实现了list和duque接口

尾进头出

同样非安全，需要collections.synchronized

fail-fast

添加方法会添加到链表末尾

add(collection c) ->添加一个集合，如果添加过程中集合出现改变，添加失败(操作变成未定义)

​	->举例子，添加的集合是自己本身

根据下标查找元素，->看下标识在链表前半段还是后半段决定从前还是从后开始找

## 3.linkedhashmap

继承了hashmap实现map接口

有一个特殊的构造器，可以将元素从最少到最多使用排序，

用这个map可以构建最少使用算法

允许空元素

内部结点类(Entry)继承了hashmap的Node类，并且新增了before和after用来记录插入顺序或者访问顺序

和hashmap一样 添加删除，包含，消耗时间恒定

有容量和加载因子，但是不推荐定义一个大容量的map，因为linkedhashmap和hashmap不同，迭代遍历时间不受容量影响

非线程安全

在插入顺序的map中，覆盖已有key的值不会改变结构

在访问顺序的map中，get会改变结构的方法

fail-fast

成员变量

```java
头结点(最老)

尾结点(最年轻)
accessOrder 访问顺序 true为按照访问次数排序，false按照插入顺序

put函数
如果进行put 操作时，如果key是已有的，那么更新完新值后会调用afterNodeAccess，表明已经访问过


afterNodeInsertion 插入后会调用这个方法，如果定义了移除规则，会执行移除。

get也会调用afterNodeAccess->modcount++结构改变
getOrDefault 如果获取到的值为null，那么返回默认的值

removeEldestEntry应用
linkedhashmap用作缓存的时候，继承linkedhashmap重写removeEldestEntry方法
private static final int MAX_ENTRIES = 100;   
protected boolean removeEldestEntry(Map.Entry eldest) {
    return size() &gt; MAX_ENTRIES;
}
一般这个方法中不可以修改map的结构
如果必须得修改的话，必须返回false

```


